import { MessageCircle, Send } from 'lucide-react';

const TikTokIcon = ({ className = 'h-4 w-4' }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/></svg>
);
const YoutubeIcon = ({ className = 'h-4 w-4' }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
);
const XIcon = ({ className = 'h-4 w-4' }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
);
const FacebookIcon = ({ className = 'h-4 w-4' }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
);
const InstagramIcon = ({ className = 'h-4 w-4' }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0z"/></svg>
);

// Each platform has its OWN signature brand color
const socialHandles = [
  { Icon: TikTokIcon, url: 'https://www.tiktok.com/@cryptorocket__1', label: 'TikTok', color: '#ff0050' },
  { Icon: MessageCircle, url: 'https://t.me/+hYhl82XOxMYzZTU8', label: 'Telegram Group', color: '#0088cc' },
  { Icon: Send, url: 'https://t.me/binarytoolkits_cryptorocket', label: 'Telegram Channel', color: '#229ED9' },
  { Icon: YoutubeIcon, url: 'https://www.youtube.com/@cryptorocket', label: 'YouTube', color: '#FF0000' },
  { Icon: XIcon, url: 'https://x.com/Cryptorocket__1', label: 'X', color: '#ffffff' },
  { Icon: FacebookIcon, url: 'https://www.facebook.com/profile.php?id=61559987323721', label: 'Facebook', color: '#1877F2' },
  { Icon: InstagramIcon, url: 'https://www.instagram.com/cryptorocket__1/', label: 'Instagram', color: '#E1306C' },
];

export default function Footer({ onNavigate }: { onNavigate: (page: string) => void }) {
  const footerLinks: { label: string; id: string }[] = [
    { label: 'About', id: 'about' },
    { label: 'Contact', id: 'contact' },
    { label: 'Privacy Policy', id: 'privacy' },
    { label: 'Disclaimer', id: 'disclaimer' },
    { label: 'Terms Of Service', id: 'terms' },
    { label: 'DMCA', id: 'dmca' },
    { label: 'Sitemap', id: 'sitemap' },
  ];

  return (
    <footer className="mt-10 border-t border-yellow-500/25 px-4 py-8 md:mt-14">
      <div className="site-shell text-center">
        {/* Small social handles - each in its own brand color */}
        <div className="mb-4 flex flex-wrap items-center justify-center gap-3">
          {socialHandles.map(({ Icon, url, label, color }) => (
            <a
              key={label}
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={label}
              title={label}
              className="transition-all duration-300 hover:scale-125"
              style={{ color }}
            >
              <Icon className="h-4 w-4 md:h-5 md:w-5" />
            </a>
          ))}
        </div>

        {/* Small legal buttons */}
        <div className="mb-5 flex flex-wrap items-center justify-center gap-2">
          {footerLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => onNavigate(link.id)}
              className="rounded-md border border-yellow-500/30 bg-black/40 px-3 py-1.5 text-[11px] font-semibold uppercase tracking-wider text-yellow-300/70 transition hover:border-yellow-400/60 hover:bg-yellow-400/10 hover:text-yellow-200"
            >
              {link.label}
            </button>
          ))}
        </div>

        <p className="mb-1 text-base font-bold text-yellow-400 md:text-lg">
          © 2026 MyToolkits | Powered By CryptoRocket
        </p>
        <p className="text-xs text-gray-500">Professional Trading & Betting Toolkits</p>
      </div>
    </footer>
  );
}
